import sys,importlib.util,json,os,time,statistics,pathlib,hashlib,traceback
from types import SimpleNamespace
root=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'sdk/python'))
spec=importlib.util.spec_from_file_location('three',root/'scripts/benchmark-three-vector-databases.py');three=importlib.util.module_from_spec(spec);spec.loader.exec_module(three);b=three.b
out=root/'build-v1.2-release/ann-checkpoint-scale-reuse';out.mkdir(exist_ok=False)
summary=json.loads((root/'build-v1.2-release/three-db-optimized-1m-performance/summary.json').read_text());assert summary['status']=='PASS'
current=summary['systems']['pacific'];scratch=root/'build-v1.2-release/three-db-optimized-1m-performance-scratch';data=pathlib.Path(current['private_scratch_root']).resolve();assert scratch.resolve() in data.parents
assert b.digest(root/'build-v1.2-ann-optimized/db_engine')==summary['sha256']['pacific']
publication=pathlib.Path('$PUBLICATION/data');manifest=json.loads((publication/'manifest.json').read_text())
for name in ['base.npy','queries.npy']:assert b.digest(publication/name)==manifest['hashes'][name]
base=b.np.load(publication/'base.npy',mmap_mode='r')[:summary['rows']];queries=b.np.load(publication/'queries.npy')
args=SimpleNamespace(build=root/'build-v1.2-ann-optimized',scratch=scratch,server_cpus=summary['server_cpus'],startup_timeout=240,metric='cosine')
s=b.Server('pacific',args,len(base),25,out);s.root.rmdir();s.root=data;os.sched_setaffinity(0,set(summary['client_cpus']))
result={'status':'RUNNING','scope':'Separate post-trial clean restart and unchanged-source 1M topology reuse; not mixed into comparative benchmark','engine_sha256':summary['sha256']['pacific'],'script_sha256':b.digest(__file__),'rows_before_mutations':len(base)}
try:
 s.start(new=False);result['startup_seconds']=s.start_seconds;assert s.count()==len(base)-5
 result['initial_index']=s.connection.request({'action':'vectorIndexStatus','collection':'vectors','name':'ann'})['index'];assert result['initial_index']['state']=='ABSENT'
 begin=time.perf_counter();s.connection.request({'action':'rebuildVectorIndex','collection':'vectors','name':'ann'});state=s.wait('ann');result['source_validation_and_import_seconds']=time.perf_counter()-begin;result['index_status']=state
 assert state.get('checkpoint_restored') is True and 'checkpoint_error' not in state,state
 overrides={i:queries[100+i] for i in range(10)}
 for worker in range(4):
  for operation in range(10):overrides[100+worker*10+operation]=queries[200+worker*10+operation]
 deleted=set(range(5));result['records']=three.verify_records(s,overrides,deleted);records=[]
 for qi in range(100,110):
  truth=b.mutable_reference(base,queries[qi],overrides,deleted)
  records.append(three.attempt(s,queries[qi],'ann',current['selected_ef_search'],qi,base,truth,'unchanged-restart',overrides=overrides,deleted=deleted))
 result['queries']=records;result['sampled_recall_at_10']=statistics.mean(x['tie_aware_recall'] for x in records);assert result['sampled_recall_at_10']>=.95
 result['count']=s.count();assert result['count']==len(base)-5;result['status']='PASS'
except BaseException:
 result['status']='FAIL';result['error']=traceback.format_exc();raise
finally:
 try:s.stop()
 except BaseException:
  result['status']='FAIL';result['shutdown_error']=traceback.format_exc();raise
 finally:
  result['resource_samples']=s.memory;result['peak_sampled_pss_bytes']=max((x['pss'] for x in s.memory),default=0);b.save(out/'result.json',result)
print(json.dumps({k:v for k,v in result.items() if k not in ['queries','resource_samples','records','index_status','initial_index']}),flush=True)
