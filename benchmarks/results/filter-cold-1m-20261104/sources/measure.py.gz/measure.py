import argparse,importlib.util,json,os,pathlib,statistics,time,traceback,sys
from types import SimpleNamespace
root=pathlib.Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'sdk/python'));spec=importlib.util.spec_from_file_location('three',root/'scripts/benchmark-three-vector-databases.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);b=m.b
p=argparse.ArgumentParser();p.add_argument('--variant',required=True);p.add_argument('--prepare-index',action='store_true');p.add_argument('--build',type=pathlib.Path,required=True);a=p.parse_args();home=pathlib.Path(__file__).resolve().parent;out=home/a.variant/'measurements';out.mkdir(exist_ok=False)
prior=json.loads((root/'build-v1.2-release/three-db-optimized-1m-performance/summary.json').read_text());assert prior['status']=='PASS';fixture=pathlib.Path(prior['systems']['pacific']['private_scratch_root']).resolve();scratch=(root/'build-v1.2-release/three-db-optimized-1m-performance-scratch').resolve();assert scratch in fixture.parents
publication=pathlib.Path('$PUBLICATION/data');manifest=json.loads((publication/'manifest.json').read_text())
for name in ['base.npy','queries.npy']:assert b.digest(publication/name)==manifest['hashes'][name]
base=b.np.load(publication/'base.npy',mmap_mode='r');queries=b.np.load(publication/'queries.npy');overrides={i:queries[100+i] for i in range(10)}
for w in range(4):
 for op in range(10):overrides[100+w*10+op]=queries[200+w*10+op]
deleted=set(range(5));ids=b.np.array([i for i in range(1,len(base),100) if i not in deleted]);filtered=b.np.array(base[ids]);positions={int(id):j for j,id in enumerate(ids)}
for id,value in overrides.items():
 if id in positions:filtered[positions[id]]=value
truth=b.reference(filtered,queries[100:110]);truth=[{'ids':[int(ids[i]) for i in x['ids']],'cutoff':x['cutoff']} for x in truth]
args=SimpleNamespace(build=a.build.resolve(),scratch=scratch,server_cpus=[0,1,2,3],startup_timeout=240);server=b.Server('pacific',args,len(base),25,out);server.root.rmdir();server.root=fixture;os.sched_setaffinity(0,{4,5});result={'status':'RUNNING','variant':a.variant,'scope':'Matched cold/OR/warm filtered exact diagnostic on the same recovered 1M fixture; both engines have the same complete metadata index; 20 measured calls per phase over 10 unique queries; application-cache cold, OS cache uncontrolled; not a fresh three-database trial','engine_sha256':b.digest(args.build/'db_engine'),'rows':len(base),'eligible_rows':len(ids),'query_indices':list(range(100,110)),'rounds':2,'warmups':2,'filter':{'group_id':1},'server_cpus':args.server_cpus,'client_cpus':[4,5]}
try:
 server.start(new=False);result['startup_seconds']=server.start_seconds;assert server.count()==len(base)-5
 result['mutation_verification']=m.verify_records(server,overrides,deleted)
 if a.prepare_index:
  existing=server.connection.request({'action':'listIndexes','collection':'vectors'})
  ready=[x for x in existing['indexes'] if x.get('field')=='group_id' and x.get('name')=='bench_group_id' and x.get('status')=='ready' and x.get('complete')]
  assert len(ready)==1,existing
  result['metadata_index_preparation']={'reused_verified_complete_index':True,'definition':ready[0],'note':'Initial createIndex attempt returned write_outcome_unknown but completed before shutdown; original failure and catalog timestamps are retained separately. No write is retried.'}
 indexes=server.connection.request({'action':'listIndexes','collection':'vectors'});result['metadata_indexes']=indexes
 assert any(x.get('field')=='group_id' and x.get('status')=='ready' and x.get('complete') for x in indexes['indexes']),indexes
 result['metadata_index_disk']=b.disk(server.root/'data/system/bench/vectors.idx')

 def query(qi,filter_):
  begin=time.perf_counter();response=server.connection.request({'action':'queryVector','collection':'vectors','vector':queries[qi].tolist(),'k':10,'metric':'cosine','search_mode':'exact','index_name':'flat','require_index':False,'filter':filter_});ms=(time.perf_counter()-begin)*1000
  assert not response.get('partial') and response['search']['executed_mode']=='exact',response
  docs=response['data'];checked=b.validate(docs,queries[qi],base,truth[qi-100],group=1,overrides=overrides,deleted=deleted)
  assert checked['strict_recall']==1. and checked['tie_aware_recall']==1.,checked
  return {'query':qi,'ms':ms,'execution':response['search'],**checked}
 result['metadata_cold_first_query']=query(100,{'group_id':1})
 assert result['metadata_cold_first_query']['execution']['candidate_source']=='merged_scan'
 phases={}
 for phase,filter_ in [('non_index_eligible_or',{'$or':[{'group_id':1},{'group_id':101}]}),('indexed_equality',{'group_id':1})]:
  if phase=='indexed_equality':
   begin=time.perf_counter();server.connection.find('vectors',{'group_id':1},limit=1);result['existing_metadata_index_warmup_seconds']=time.perf_counter()-begin
  warmups=[query(qi,filter_) for qi in range(100,102)]
  rounds=[]
  for round_ in range(2):
   records=[]
   for qi in range(100,110):
    record=query(qi,filter_);record['round']=round_+1
    if a.variant=='candidate' and phase=='indexed_equality':assert record['execution']['candidate_source']=='metadata_index' and record['execution']['metadata_index_candidates']==len(ids),record
    if phase=='non_index_eligible_or':assert record['execution']['candidate_source']=='merged_scan',record
    records.append(record);print(json.dumps({'phase':phase,'round':round_+1,'query':qi,'ms':record['ms'],'recall':record['tie_aware_recall']}),flush=True)
   rounds.append({'p50_ms':statistics.median(x['ms'] for x in records),'records':records})
   phases[phase]={'warmup_records':warmups,'rounds_results':rounds,'median_of_round_medians_ms':statistics.median(x['p50_ms'] for x in rounds)};result['phases']=phases;b.save(out/'progress.json',result)
 assert server.count()==len(base)-5;result['status']='PASS'
except BaseException:result['status']='FAIL';result['error']=traceback.format_exc();raise
finally:
 try:server.stop()
 except BaseException:result['status']='FAIL';result['shutdown_error']=traceback.format_exc();raise
 finally:result['peak_sampled_pss_bytes']=max((x['pss'] for x in server.memory),default=0);result['resource_samples']=server.memory;b.save(out/'result.json',result)
print(json.dumps({k:v for k,v in result.items() if k not in ['rounds_results','resource_samples','mutation_verification']}),flush=True)
