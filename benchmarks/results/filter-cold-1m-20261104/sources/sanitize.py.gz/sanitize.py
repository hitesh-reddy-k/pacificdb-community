import pathlib,subprocess,json,time,os,hashlib,traceback,shlex
root=pathlib.Path(__file__).resolve().parents[2];os.chdir(root);out=pathlib.Path(__file__).resolve().parent;r={'status':'RUNNING','started_at':time.time(),'scope':'LSM, DatabaseEngine, storage_format_v2 and cold-filter test translation units instrumented; linked dependencies do not constitute a fully sanitized engine'}
link=shlex.split((root/'build-v1.2-ann-optimized/CMakeFiles/db_engine_vector_cold_filter_test.dir/link.txt').read_text());libs=link[link.index('libpacificdb_engine_core.a'):];libs=[str(root/'build-v1.2-ann-optimized'/x) if x.endswith('.a') and not x.startswith('/') else x for x in libs]
base=['/usr/bin/c++','-std=c++17','-O1','-g1','-fno-omit-frame-pointer','-DHAS_OPENSSL','-DLINUX','-Iengine/include','-Ibuild-v1.2-deps/usr/include','-Ibuild-v1.2-deps/usr/include/x86_64-linux-gnu','-pthread','engine/test/vector_cold_filter_test.cpp','engine/src/lsm.cpp','engine/src/database_engine.cpp','engine/src/storage_format_v2.cpp',*libs]
try:
 for label,flag,extra in [('asan-ubsan','address,undefined',{'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1'}),('tsan','thread',{'TSAN_OPTIONS':'halt_on_error=1'})]:
  target=out/('metadata-'+label);r['phase']=label;command=base+['-fsanitize='+flag,'-o',str(target)];r[label]={'command':command}
  (out/'sanitizers-controller.json').write_text(json.dumps(r,indent=2))
  with (out/(label+'-build.log')).open('w') as log:code=subprocess.call(command,stdout=log,stderr=subprocess.STDOUT)
  r[label]['build_exit_code']=code;assert code==0,(label,'build',code)
  for mode,args in [('cold-filter',[])]:
   with (out/(label+'-'+mode+'.log')).open('w') as log:p=subprocess.run([str(target),*args],stdout=log,stderr=subprocess.STDOUT,env={**os.environ,**extra},timeout=180)
   r[label][mode+'_exit_code']=p.returncode;assert p.returncode==0,(label,mode,p.returncode)
  r[label]['binary_sha256']=hashlib.sha256(target.read_bytes()).hexdigest()
 r['status']='PASS'
except BaseException:r['status']='FAIL';r['error']=traceback.format_exc()
finally:r['finished_at']=time.time();(out/'sanitizers-exit.json').write_text(json.dumps(r,indent=2))
