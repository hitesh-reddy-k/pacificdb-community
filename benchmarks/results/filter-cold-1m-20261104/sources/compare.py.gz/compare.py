import pathlib,json,statistics,hashlib
root=pathlib.Path(__file__).resolve().parents[2];out=pathlib.Path(__file__).resolve().parent
all_={v:json.loads((out/v/'measurements/result.json').read_text()) for v in ['baseline','candidate','baseline-recheck']}
assert all(x['status']=='PASS' for x in all_.values())
r={'status':'PASS','scope':'Recovered 1M/cosine25/top10, 999995 survivors, 9999 eligible; same ready metadata index and unchanged durability; Linux x64 development diagnostic, not a new cross-database trial','engine_sha256':{v:x['engine_sha256'] for v,x in all_.items()},'variants':{},'comparison':{}}
for v,x in all_.items():
 r['variants'][v]={'metadata_cold_first_query_ms':x['metadata_cold_first_query']['ms'],'indexed_first_payload_cold_ms':x['phases']['indexed_equality']['warmup_records'][0]['ms'],'metadata_cache_warmup_ms':x['existing_metadata_index_warmup_seconds']*1000,'peak_sampled_pss_mib':x['peak_sampled_pss_bytes']/2**20,'phases':{p:y['median_of_round_medians_ms'] for p,y in x['phases'].items()}}
 records=[x['metadata_cold_first_query']]+[a for y in x['phases'].values() for a in y['warmup_records']]+[a for y in x['phases'].values() for z in y['rounds_results'] for a in z['records']]
 assert len(records)==45 and all(a['strict_recall']==1 and a['tie_aware_recall']==1 for a in records)
 r['variants'][v]['validated_queries']=len(records)
for phase in ['non_index_eligible_or','indexed_equality']:
 before=[z['p50_ms'] for v in ['baseline','baseline-recheck'] for z in all_[v]['phases'][phase]['rounds_results']];baseline=statistics.median(before);candidate=all_['candidate']['phases'][phase]['median_of_round_medians_ms']
 r['comparison'][phase]={'baseline_median_of_four_round_medians_ms':baseline,'candidate_ms':candidate,'speedup':baseline/candidate,'latency_reduction_percent':100*(1-candidate/baseline)}
for key in ['metadata_cold_first_query_ms','indexed_first_payload_cold_ms']:
 values=[r['variants'][v][key] for v in ['baseline','baseline-recheck']];baseline=statistics.median(values);candidate=r['variants']['candidate'][key]
 r['comparison'][key]={'baseline_median_ms':baseline,'baseline_samples_ms':values,'candidate_ms':candidate,'speedup':baseline/candidate,'limitation':'One application-cold observation per process; OS cache uncontrolled; no tail or population conclusions'}
(out/'comparison.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
