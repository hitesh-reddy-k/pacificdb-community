import argparse,importlib.util,json,os,pathlib,statistics,time,traceback,sys
from types import SimpleNamespace
root=pathlib.Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'sdk/python'));spec=importlib.util.spec_from_file_location('three',root/'scripts/benchmark-three-vector-databases.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);b=m.b
p=argparse.ArgumentParser();p.add_argument('--variant',required=True);p.add_argument('--build',type=pathlib.Path,required=True);a=p.parse_args();home=pathlib.Path(__file__).resolve().parent;out=home/a.variant/'measurements';out.mkdir(exist_ok=False)
prior=json.loads((root/'build-v1.2-release/three-db-optimized-1m-performance/summary.json').read_text());assert prior['status']=='PASS';fixture=pathlib.Path(prior['systems']['pacific']['private_scratch_root']).resolve();scratch=(root/'build-v1.2-release/three-db-optimized-1m-performance-scratch').resolve();assert scratch in fixture.parents
publication=pathlib.Path('$PUBLICATION/data');manifest=json.loads((publication/'manifest.json').read_text())
for name in ['base.npy','queries.npy']:assert b.digest(publication/name)==manifest['hashes'][name]
base=b.np.load(publication/'base.npy',mmap_mode='r');queries=b.np.load(publication/'queries.npy');overrides={i:queries[100+i] for i in range(10)}
for w in range(4):
 for op in range(10):overrides[100+w*10+op]=queries[200+w*10+op]
deleted=set(range(5));ids=b.np.array([i for i in range(1,len(base),100) if i not in deleted]);filtered=b.np.array(base[ids]);positions={int(id):j for j,id in enumerate(ids)}
for id,value in overrides.items():
 if id in positions:filtered[positions[id]]=value
truth=b.reference(filtered,queries[100:110]);truth=[{'ids':[int(ids[i]) for i in x['ids']],'cutoff':x['cutoff']} for x in truth]
args=SimpleNamespace(build=a.build.resolve(),scratch=scratch,server_cpus=[0,1,2,3],startup_timeout=240);server=b.Server('pacific',args,len(base),25,out);server.root.rmdir();server.root=fixture;os.sched_setaffinity(0,{4,5});result={'status':'RUNNING','variant':a.variant,'scope':'Matched baseline/candidate filtered exact diagnostic on the same recovered 1M fixture; 20 measured calls over 10 unique queries, not a fresh three-database trial','engine_sha256':b.digest(args.build/'db_engine'),'rows':len(base),'eligible_rows':len(ids),'query_indices':list(range(100,110)),'rounds':2,'warmups':2,'filter':{'group_id':1},'server_cpus':args.server_cpus,'client_cpus':[4,5]}
try:
 server.start(new=False);result['startup_seconds']=server.start_seconds;assert server.count()==len(base)-5
 result['mutation_verification']=m.verify_records(server,overrides,deleted)
 for qi in range(100,102):server.query(queries[qi],'exact',100,group=1)
 rounds=[]
 for round_ in range(2):
  records=[]
  for qi in range(100,110):
   docs,ms,execution=server.query(queries[qi],'exact',100,group=1);checked=b.validate(docs,queries[qi],base,truth[qi-100],group=1,overrides=overrides,deleted=deleted);assert checked['tie_aware_recall']==1.;record={'query':qi,'round':round_+1,'ms':ms,'execution':execution,**checked};records.append(record);print(json.dumps({'round':round_+1,'query':qi,'ms':ms,'recall':checked['tie_aware_recall']}),flush=True)
  rounds.append({'p50_ms':statistics.median(x['ms'] for x in records),'records':records});result['rounds_results']=rounds;b.save(out/'progress.json',result)
 result['median_of_round_medians_ms']=statistics.median(x['p50_ms'] for x in rounds);assert server.count()==len(base)-5;result['status']='PASS'
except BaseException:result['status']='FAIL';result['error']=traceback.format_exc();raise
finally:
 try:server.stop()
 except BaseException:result['status']='FAIL';result['shutdown_error']=traceback.format_exc();raise
 finally:result['peak_sampled_pss_bytes']=max((x['pss'] for x in server.memory),default=0);result['resource_samples']=server.memory;b.save(out/'result.json',result)
print(json.dumps({k:v for k,v in result.items() if k not in ['rounds_results','resource_samples','mutation_verification']}),flush=True)
