import pathlib,subprocess,json,time,os,traceback,hashlib
root=pathlib.Path(__file__).resolve().parents[2];os.chdir(root);out=pathlib.Path(__file__).resolve().parent;r={'status':'RUNNING','started_at':time.time(),'pid':os.getpid()};env={**os.environ,'PATH':'$NODE_PREFIX/bin:'+os.environ['PATH']}
try:
 commands=[('all-target-build',['cmake','--build','build-v1.2-ann-optimized','-j2']),('checkpoint',['python3','scripts/test-vector-checkpoint.py','--build','build-v1.2-ann-optimized','--failpoint-build','build-v1.2-ann-optimized-failpoints','--expected-version','1.2.0','--evidence',str(out/'checkpoint')])]
 for name,cmd in commands:
  r['phase']=name
  with (out/(name+'.log')).open('w') as log:
   p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=env);r['child_pid']=p.pid
   while p.poll() is None:r['heartbeat_at']=time.time();(out/'validation-controller.json').write_text(json.dumps(r,indent=2));time.sleep(5)
   r[name]={'exit_code':p.returncode,'finished_at':time.time()};assert p.returncode==0,(name,p.returncode)
 r['engine_sha256']=hashlib.sha256((root/'build-v1.2-ann-optimized/db_engine').read_bytes()).hexdigest()
 # Sanitizer compilation/testing is supervised separately. Do not time queries
 # while another qualification process is still using the workstation.
 while not (out/'sanitizers-exit.json').exists():time.sleep(5)
 sanitizer=json.loads((out/'sanitizers-exit.json').read_text());assert sanitizer['status']=='PASS',sanitizer
 for variant,build in [('candidate','build-v1.2-ann-optimized'),('baseline-recheck','build-v1.2-release/filter-fast-scalar-20261103/baseline')]:
  (out/variant).mkdir(exist_ok=False);r['phase']=variant;(out/'validation-controller.json').write_text(json.dumps(r,indent=2))
  code=subprocess.call(['/usr/bin/python3',str(out/'run.py'),variant,build],env=env);receipt=json.loads((out/(variant+'-exit.json')).read_text());r[variant]=receipt;assert code==0 and receipt['status']=='PASS',receipt
 r['status']='PASS'
except BaseException:r['status']='FAIL';r['error']=traceback.format_exc()
finally:r['finished_at']=time.time();(out/'validation-exit.json').write_text(json.dumps(r,indent=2))
