import subprocess,time,json,pathlib,sys,os,traceback,signal
root=pathlib.Path(__file__).resolve().parents[2];os.chdir(root);out=pathlib.Path(__file__).resolve().parent;variant=sys.argv[1];build=sys.argv[2];r={'status':'RUNNING','variant':variant,'started_at':time.time(),'pid':os.getpid()};original=subprocess.check_output(['powerprofilesctl','get'],text=True).strip();r['original_profile']=original
signal.signal(signal.SIGTERM,lambda signum,frame:(_ for _ in ()).throw(KeyboardInterrupt('terminated')))
try:
 with (out/(variant+'.log')).open('w') as log:
  command=['powerprofilesctl','launch','--profile','performance','--reason','Matched filtered vector query diagnostic','--appid','io.pacificdb.benchmark',str(root/'build-v1.2-release/benchmark-rc2-venv/bin/python'),str(out/'measure.py'),'--variant',variant,'--build',build];p=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT);r['child_pid']=p.pid
  while p.poll() is None:r['heartbeat_at']=time.time();r['profile']=subprocess.check_output(['powerprofilesctl','get'],text=True).strip();(out/(variant+'-controller.json')).write_text(json.dumps(r,indent=2));time.sleep(5)
  r['exit_code']=p.returncode;r['status']='PASS' if p.returncode==0 else 'FAIL'
except BaseException:r['status']='INCOMPLETE';r['error']=traceback.format_exc()
finally:r['restore_exit_code']=subprocess.run(['powerprofilesctl','set',original]).returncode;r['finished_at']=time.time();(out/(variant+'-exit.json')).write_text(json.dumps(r,indent=2))
