import pathlib,subprocess,json,time,os,traceback,hashlib
root=pathlib.Path(__file__).resolve().parents[2];os.chdir(root);out=pathlib.Path(__file__).resolve().parent;r={'status':'RUNNING','started_at':time.time(),'scope':'storage_format_v2.cpp and storage_format_v2_test.cpp instrumented; linked dependencies are not a full engine sanitizer build'}
base=['/usr/bin/c++','-std=c++17','-O1','-g','-fno-omit-frame-pointer','-Iengine/include','-Ibuild-v1.2-deps/usr/include','-Ibuild-v1.2-deps/usr/include/x86_64-linux-gnu','-pthread','engine/test/storage_format_v2_test.cpp','engine/src/storage_format_v2.cpp','build-v1.2-ann-optimized/libpacificdb_engine_core.a','build-v1.2-ann-optimized/libpacificdb_test_failpoints_disabled.a','/usr/lib/x86_64-linux-gnu/libre2.so.11','build-v1.2-ann-optimized/libpacificdb_lexical_core.a','build-v1.2-ann-optimized/libpacificdb_flat_vector_core.a','build-v1.2-ann-optimized/libpacificdb_media_upload_state.a','build-v1.2-ann-optimized/libpacificdb_structured_event.a','/usr/lib/x86_64-linux-gnu/libssl.so.3','/usr/lib/x86_64-linux-gnu/libcrypto.so.3','/usr/lib/x86_64-linux-gnu/liblz4.so.1']
try:
 for label,flag,env in [('asan-ubsan','address,undefined',{'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1'}),('tsan','thread',{'TSAN_OPTIONS':'halt_on_error=1'})]:
  target=out/('storage-'+label);cmd=base+['-fsanitize='+flag,'-o',str(target)];r[label]={'command':cmd}
  with (out/(label+'-build.log')).open('w') as log:code=subprocess.call(cmd,stdout=log,stderr=subprocess.STDOUT)
  r[label]['build_exit_code']=code;assert code==0,(label,'build',code)
  with (out/(label+'-run.log')).open('w') as log:code=subprocess.call([str(target)],stdout=log,stderr=subprocess.STDOUT,env={**os.environ,**env})
  r[label].update({'test_exit_code':code,'binary_sha256':hashlib.sha256(target.read_bytes()).hexdigest()});assert code==0,(label,'test',code)
 r['status']='PASS'
except BaseException:r['status']='FAIL';r['error']=traceback.format_exc()
finally:r['finished_at']=time.time();(out/'sanitizers-exit.json').write_text(json.dumps(r,indent=2))
