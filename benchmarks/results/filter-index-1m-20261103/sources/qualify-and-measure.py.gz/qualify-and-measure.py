import pathlib,subprocess,os,time,json,traceback,hashlib
root=pathlib.Path(__file__).resolve().parents[2];os.chdir(root);out=pathlib.Path(__file__).resolve().parent;r={'status':'RUNNING','started_at':time.time(),'pid':os.getpid()};env={**os.environ,'PATH':'$NODE_PREFIX/bin:'+os.environ['PATH']}
def run(name,cmd):
 r['phase']=name
 with (out/(name+'.log')).open('w') as log:
  p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=env);r['child_pid']=p.pid
  while p.poll() is None:r['heartbeat_at']=time.time();(out/'controller.json').write_text(json.dumps(r,indent=2));time.sleep(5)
  r[name]={'exit_code':p.returncode,'finished_at':time.time()};assert p.returncode==0,(name,p.returncode)
try:
 # Wait for the current manually supervised compilers; never mutate one build
 # tree from two CMake invocations. Exact-source final rebuild follows.
 import psutil
 while any('cmake --build build-v1.2-ann-optimized' in ' '.join(p.info['cmdline'] or []) for p in psutil.process_iter(['cmdline']) if p.pid!=os.getpid() and p.name()=='cmake'):time.sleep(5)
 run('final-production-build',['cmake','--build','build-v1.2-ann-optimized','-j2'])
 run('final-failpoint-build',['cmake','--build','build-v1.2-ann-optimized-failpoints','--target','db_engine','-j2'])
 run('targeted-green',['build-v1.2-ann-optimized/db_engine_vector_metadata_filter_test'])
 run('publication-gap-green',['build-v1.2-ann-optimized/db_engine_vector_metadata_filter_test','--publication-gap'])
 run('checkpoint',['python3','scripts/test-vector-checkpoint.py','--build','build-v1.2-ann-optimized','--failpoint-build','build-v1.2-ann-optimized-failpoints','--expected-version','1.2.0','--evidence',str(out/'checkpoint')])
 run('cross-sdk',['node','scripts/test-cross-sdk-e2e.mjs','build-v1.2-ann-optimized'])
 r['engine_sha256']=hashlib.sha256((root/'build-v1.2-ann-optimized/db_engine').read_bytes()).hexdigest()
 for variant,build in [('baseline','build-v1.2-release/filter-index-20261103/baseline'),('candidate','build-v1.2-ann-optimized'),('baseline-recheck','build-v1.2-release/filter-index-20261103/baseline')]:
  (out/variant).mkdir(exist_ok=True)
  run(variant,['python3',str(out/'run.py'),variant,build]);receipt=json.loads((out/(variant+'-exit.json')).read_text());assert receipt['status']=='PASS',receipt
 r['status']='PASS'
except BaseException:r['status']='FAIL';r['error']=traceback.format_exc()
finally:r['finished_at']=time.time();(out/'exit.json').write_text(json.dumps(r,indent=2))
