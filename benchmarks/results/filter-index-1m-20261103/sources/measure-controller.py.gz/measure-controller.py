import pathlib,subprocess,json,os,time,traceback
root=pathlib.Path(__file__).resolve().parents[2];os.chdir(root);out=pathlib.Path(__file__).resolve().parent;r={'status':'RUNNING','started_at':time.time(),'pid':os.getpid()}
try:
 assert json.loads((out/'checkpoint/summary.json').read_text())['status']=='PASS'
 assert json.loads((out/'sanitizers-exit.json').read_text())['status']=='PASS'
 for variant,build in [('baseline','build-v1.2-release/filter-index-20261103/baseline'),('candidate','build-v1.2-ann-optimized'),('baseline-recheck','build-v1.2-release/filter-index-20261103/baseline')]:
  (out/variant).mkdir(exist_ok=True);r['phase']=variant;p=subprocess.Popen(['python3',str(out/'run.py'),variant,build]);r['child_pid']=p.pid
  while p.poll() is None:r['heartbeat_at']=time.time();(out/'measurement-controller.json').write_text(json.dumps(r,indent=2));time.sleep(5)
  receipt=json.loads((out/(variant+'-exit.json')).read_text());r[variant]=receipt;assert p.returncode==0 and receipt['status']=='PASS',receipt
 r['status']='PASS'
except BaseException:r['status']='FAIL';r['error']=traceback.format_exc()
finally:r['finished_at']=time.time();(out/'measurement-exit.json').write_text(json.dumps(r,indent=2))
